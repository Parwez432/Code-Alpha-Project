 // Gallery data
        const galleryData = [
            { id: 1, src: "https://picsum.photos/800/600?random=1", alt: "Mountain landscape", category: "nature" },
            { id: 2, src: "https://picsum.photos/800/600?random=2", alt: "City skyline at night", category: "city" },
            { id: 3, src: "https://picsum.photos/800/600?random=3", alt: "Wild lion in savanna", category: "animals" },
            { id: 4, src: "https://picsum.photos/800/600?random=4", alt: "Beautiful sunset over lake", category: "nature" },
            { id: 5, src: "https://picsum.photos/800/600?random=5", alt: "Modern urban architecture", category: "city" },
            { id: 6, src: "https://picsum.photos/800/600?random=6", alt: "Elephant in the wild", category: "animals" },
            { id: 7, src: "https://picsum.photos/800/600?random=7", alt: "Forest with morning fog", category: "nature" },
            { id: 8, src: "https://picsum.photos/800/600?random=8", alt: "Busy downtown street", category: "city" },
            { id: 9, src: "https://picsum.photos/800/600?random=9", alt: "Colorful tropical fish", category: "animals" },
            { id: 10, src: "https://picsum.photos/800/600?random=10", alt: "Waterfall in the jungle", category: "nature" },
            { id: 11, src: "https://picsum.photos/800/600?random=11", alt: "Aerial city view", category: "city" },
            { id: 12, src: "https://picsum.photos/800/600?random=12", alt: "Panda eating bamboo", category: "animals" }
        ];

        // DOM elements
        const galleryGrid = document.querySelector('.grid');
        const filterButtons = document.querySelectorAll('.filter-btn');
        const lightbox = document.querySelector('.lightbox');
        const lightboxImage = document.getElementById('lightbox-image');
        const lightboxCaption = document.getElementById('lightbox-caption');
        const closeLightbox = document.querySelector('.close-lightbox');
        const prevBtn = document.querySelector('.prev-btn');
        const nextBtn = document.querySelector('.next-btn');

        // Current image index for lightbox navigation
        let currentImageIndex = 0;

        // Initialize gallery
        function initGallery() {
            renderGalleryItems(galleryData);
            setupEventListeners();
        }

        // Render gallery items
        function renderGalleryItems(items) {
            galleryGrid.innerHTML = '';
            items.forEach((item, index) => {
                const galleryItem = document.createElement('div');
                galleryItem.className = 'gallery-item bg-white rounded-lg overflow-hidden shadow-md cursor-pointer';
                galleryItem.dataset.category = item.category;
                galleryItem.dataset.index = index;
                
                galleryItem.innerHTML = `
                    <img src="${item.src}" alt="${item.alt}" class="w-full h-48 object-cover" loading="lazy">
                    <div class="p-4">
                        <p class="text-gray-700">${item.alt}</p>
                        <span class="inline-block mt-2 px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">${item.category}</span>
                    </div>
                `;
                
                galleryGrid.appendChild(galleryItem);
            });
        }

        // Setup event listeners
        function setupEventListeners() {
            // Filter buttons
            filterButtons.forEach(button => {
                button.addEventListener('click', () => {
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    button.classList.add('active');
                    
                    const filter = button.dataset.filter;
                    if (filter === 'all') {
                        renderGalleryItems(galleryData);
                    } else {
                        const filteredItems = galleryData.filter(item => item.category === filter);
                        renderGalleryItems(filteredItems);
                    }
                });
            });

            // Gallery item click (open lightbox)
            galleryGrid.addEventListener('click', (e) => {
                const galleryItem = e.target.closest('.gallery-item');
                if (galleryItem) {
                    currentImageIndex = parseInt(galleryItem.dataset.index);
                    openLightbox(currentImageIndex);
                }
            });

            // Lightbox controls
            closeLightbox.addEventListener('click', closeLightboxHandler);
            prevBtn.addEventListener('click', showPrevImage);
            nextBtn.addEventListener('click', showNextImage);
            document.addEventListener('keydown', handleKeyboardNavigation);
        }

        // Open lightbox
        function openLightbox(index) {
            const item = galleryData[index];
            lightboxImage.src = item.src;
            lightboxImage.alt = item.alt;
            lightboxCaption.textContent = item.alt;
            lightbox.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }

        // Close lightbox
        function closeLightboxHandler() {
            lightbox.classList.add('hidden');
            document.body.style.overflow = '';
        }

        // Show previous image
        function showPrevImage() {
            currentImageIndex = (currentImageIndex - 1 + galleryData.length) % galleryData.length;
            openLightbox(currentImageIndex);
        }

        // Show next image
        function showNextImage() {
            currentImageIndex = (currentImageIndex + 1) % galleryData.length;
            openLightbox(currentImageIndex);
        }

        // Keyboard navigation
        function handleKeyboardNavigation(e) {
            if (!lightbox.classList.contains('hidden')) {
                if (e.key === 'Escape') {
                    closeLightboxHandler();
                } else if (e.key === 'ArrowLeft') {
                    showPrevImage();
                } else if (e.key === 'ArrowRight') {
                    showNextImage();
                }
            }
        }

        // Initialize the gallery
        document.addEventListener('DOMContentLoaded', initGallery);