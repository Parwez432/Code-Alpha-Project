 // Music data
        const songs = [
            {
                title: "Blinding Lights",
                artist: "The Weeknd",
                duration: 203,
                cover: "https://picsum.photos/300/300?random=1"
            },
            {
                title: "Save Your Tears",
                artist: "The Weeknd",
                duration: 215,
                cover: "https://picsum.photos/300/300?random=2"
            },
            {
                title: "Starboy",
                artist: "The Weeknd ft. Daft Punk",
                duration: 230,
                cover: "https://picsum.photos/300/300?random=3"
            },
            {
                title: "Take My Breath",
                artist: "The Weeknd",
                duration: 221,
                cover: "https://picsum.photos/300/300?random=4"
            },
            {
                title: "Die For You",
                artist: "The Weeknd",
                duration: 260,
                cover: "https://picsum.photos/300/300?random=5"
            }
        ];

        // Audio element
        const audio = new Audio();
        let currentSongIndex = 0;
        let isPlaying = false;
        let isAutoplay = false;

        // DOM elements
        const playBtn = document.getElementById('playBtn');
        const playIcon = document.getElementById('playIcon');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const progressBar = document.getElementById('progressBar');
        const progressContainer = document.getElementById('progressContainer');
        const currentTimeElement = document.getElementById('currentTime');
        const durationElement = document.getElementById('duration');
        const remainingTimeElement = document.getElementById('remainingTime');
        const songTitleElement = document.getElementById('songTitle');
        const artistNameElement = document.getElementById('artistName');
        const albumArtElement = document.getElementById('albumArt');
        const volumeControl = document.getElementById('volumeControl');
        const playlistElement = document.getElementById('playlist');
        const autoplayToggle = document.getElementById('autoplayToggle');

        // Initialize player
        function initPlayer() {
            loadSong(currentSongIndex);
            renderPlaylist();
            
            // Event listeners
            playBtn.addEventListener('click', togglePlay);
            prevBtn.addEventListener('click', prevSong);
            nextBtn.addEventListener('click', nextSong);
            progressContainer.addEventListener('click', setProgress);
            volumeControl.addEventListener('input', setVolume);
            autoplayToggle.addEventListener('change', toggleAutoplay);
            
            // Time update
            audio.addEventListener('timeupdate', updateProgress);
            audio.addEventListener('ended', songEnded);
            audio.addEventListener('loadedmetadata', updateDuration);
        }

        // Load song
        function loadSong(index) {
            const song = songs[index];
            audio.src = `https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${index + 1}.mp3`;
            songTitleElement.textContent = song.title;
            artistNameElement.textContent = song.artist;
            albumArtElement.src = song.cover;
            
            // Highlight current song in playlist
            const playlistItems = document.querySelectorAll('.playlist-item');
            playlistItems.forEach(item => item.classList.remove('bg-purple-600'));
            playlistItems[index].classList.add('bg-purple-600');
        }

        // Toggle play/pause
        function togglePlay() {
            if (isPlaying) {
                pauseSong();
            } else {
                playSong();
            }
        }

        // Play song
        function playSong() {
            isPlaying = true;
            playIcon.classList.replace('fa-play', 'fa-pause');
            audio.play();
        }

        // Pause song
        function pauseSong() {
            isPlaying = false;
            playIcon.classList.replace('fa-pause', 'fa-play');
            audio.pause();
        }

        // Previous song
        function prevSong() {
            currentSongIndex--;
            if (currentSongIndex < 0) {
                currentSongIndex = songs.length - 1;
            }
            loadSong(currentSongIndex);
            if (isPlaying) {
                playSong();
            }
        }

        // Next song
        function nextSong() {
            currentSongIndex++;
            if (currentSongIndex > songs.length - 1) {
                currentSongIndex = 0;
            }
            loadSong(currentSongIndex);
            if (isPlaying) {
                playSong();
            }
        }

        // Song ended
        function songEnded() {
            if (isAutoplay) {
                nextSong();
            } else {
                pauseSong();
                audio.currentTime = 0;
            }
        }

        // Update progress bar
        function updateProgress() {
            const { duration, currentTime } = audio;
            const progressPercent = (currentTime / duration) * 100;
            progressBar.style.width = `${progressPercent}%`;
            
            // Update time display
            currentTimeElement.textContent = formatTime(currentTime);
            remainingTimeElement.textContent = `-${formatTime(duration - currentTime)}`;
            
            // Move time indicator with progress
            currentTimeElement.style.left = `${progressPercent}%`;
        }

        // Update duration display
        function updateDuration() {
            durationElement.textContent = formatTime(audio.duration);
        }

        // Set progress
        function setProgress(e) {
            const width = this.clientWidth;
            const clickX = e.offsetX;
            const duration = audio.duration;
            audio.currentTime = (clickX / width) * duration;
        }

        // Set volume
        function setVolume() {
            audio.volume = this.value;
        }

        // Toggle autoplay
        function toggleAutoplay() {
            isAutoplay = this.checked;
        }

        // Format time (seconds to MM:SS)
        function formatTime(seconds) {
            const minutes = Math.floor(seconds / 60);
            const secs = Math.floor(seconds % 60);
            return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
        }

        // Render playlist
        function renderPlaylist() {
            playlistElement.innerHTML = songs.map((song, index) => `
                <li class="playlist-item flex justify-between items-center p-2 rounded hover:bg-gray-600 cursor-pointer transition-colors ${index === currentSongIndex ? 'bg-purple-600' : ''}" data-index="${index}">
                    <div>
                        <div class="font-medium">${song.title}</div>
                        <div class="text-sm text-gray-400">${song.artist}</div>
                    </div>
                    <div class="text-sm text-gray-400">${formatTime(song.duration)}</div>
                </li>
            `).join('');
            
            // Add click event to playlist items
            document.querySelectorAll('.playlist-item').forEach(item => {
                item.addEventListener('click', function() {
                    currentSongIndex = parseInt(this.getAttribute('data-index'));
                    loadSong(currentSongIndex);
                    if (!isPlaying) {
                        playSong();
                    }
                });
            });
        }

        // Initialize the player
        initPlayer();